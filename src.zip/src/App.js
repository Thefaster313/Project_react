import './App.css';
import React, {Component} from 'react';
import Additems from './component/Additems/Additems';
import Itemslist from './component/Itemslist/Itemslist';

class App extends Component{
  state={items:[
    {id:1,name:'hamza',age:'22'},
    {id:2,name:'taher',age:'23'},
    {id:3,name:'omar',age:'24'},
   ]}

   
   deleteItem= (id) =>{
     let itemss=this.state.items.filter(item => {
       return item.id !==id
      
     })
     
     this.setState({items:itemss},
      console.log(itemss ),
     
      
      )
    
     
   }
   addItem= (item)=>{
let items=this.state.items;
items.push(item);
this.setState({items:items})
   }
 
  render(){
    return(
      //< >
      <div className="App container" >
        <h1 className="text-center">
        Todo List
        </h1> 
        <Itemslist  items={this.state.items} deleteItem={this.deleteItem}/>       
        <Additems addItem={this.addItem} />
       
      </div >

            );
  }
}
export default App;